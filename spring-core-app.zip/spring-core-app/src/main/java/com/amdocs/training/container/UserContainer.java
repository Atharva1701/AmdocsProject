package com.amdocs.training.container;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.amdocs.training.model.User;

public class UserContainer {

	public static void main(String[] args) {
		
//		ApplicationContext context = new ClassPathXmlApplicationContext("user-constructor.xml");
//		
//		User user = (User) context.getBean("user");
//		System.out.println(user.getCourse());
		
		AnnotationConfigApplicationContext context1 = new AnnotationConfigApplicationContext();
		context1.scan("com.amdocs.training");
		context1.refresh();
		
		User user1 = context1.getBean(User.class);
		System.out.println(user1);
	}

}
